// mantissa = m*2^bexp = [1e29, 1e30-1] = [0x.a18fp97, 0x.c9f2p100]
// dec-bin error
// = (chop 31+ digits error) + (chop 1 to 4 bits error)
// = 2^96 / (m*2^bexp) + (1 - 2^(96-bexp)) / m
// = 1 / m
// max(dec-bin error) = max(1 / m) = 2 ulp
//
// total rel error = 2 + 18.7026 + 1/m = 20.7026 + 1/m
// total abs error = 20.7026 m + 1 = 21 ulp

#include "m_apm.h"
#include "dtoa-fast.h"
#include "mapm_clz.c"

#define ULP()   M_check_ulp(r, n2, n1, bexp)
#undef  HOLE    // 30 digits instead of only 29
#define HOLE    ~21U

static int M_check_ulp(M_APM d, unsigned n2, unsigned n1, int bexp)
{
  if (d->m_apm_exponent >= d->m_apm_datalength)
    if (bexp <= 91+BIAS)        // d (int) < 0x1p91
      return 0;                 // |d-b| < 1, thus d = b

  M_APM b = M_get_stack_var();  // half-way binary estimate
  n1 = ((n1>>9) + 1) >> 1;      // build rounded-up 54 bits
  m_apm_set_uint64_t(b, ((uint64_t)n2<<22) + n1);
  m_apm_ishift(b, bexp-BIAS-54);

  int sign = m_apm_compare_absolute(d, b);
  M_restore_stack(1);
  return sign;
}

static double M_to_double (M_APM r, uint64_t top, unsigned bot,
                           int bexp, int i)
{
  static unsigned t[] = {   // normalized 10^0 to 10^12
    0x80000000, 0xa0000000, 0xc8000000, 0xfa000000,
    0x9c400000, 0xc3500000, 0xf4240000, 0x98968000,
    0xbebc2000, 0xee6b2800, 0x9502f900, 0xba43b740, 0xe8d4a510
  };
  static char t_bexp[] = {1,4,7,10,14,17,20,24,27,30,34,37,40};

  unsigned n2 = top >> 32;  // top    32 bits
  unsigned n1 = top;        // middle 32 bits
  unsigned n0 = bot;        // bottom 32 bits

  for(; i < 0; i += 73) DIV_1E73(n2,n1,n0,bexp);
  for(; i>=60; i -= 60) MUL_1E60(n2,n1,n0,bexp);
  for(; i>=25; i -= 25) MUL_1E25(n2,n1,n0,bexp);
  for(; i>=13; i -= 12) MUL_1E12(n2,n1,n0,bexp);
  MUL32(n2,n1,n0,bexp, t[i], t_bexp[i]);

  bot = n0;
  if ((unsigned) bexp >= 2046) {  // not normal number !
    if (bexp >= 2046) return HUGE_VAL;
    i = -bexp;
    bexp = 0;
    uint64_t tail = ((uint64_t) n1 << 32 | n0) >> i;
    n0 = tail |= (uint64_t) n2 << (64-i);
    n1 = tail >> 32;
    n2 = (uint64_t) n2 >> i;      // fix sub-normal
  }

  if (bot == 0) {
    if ((n1 & 0xfff) == 0x400)    // round 01000 ...
      if (n0 == 0)
        n1 += ULP() - 1;
  } else if (bot > HOLE) {
    if ((n1 & 0x7ff) == 0x3ff)    // round ?0111 ...
      if (n0 > HOLE)
        n1 += ULP() + !!(n1&0x800);
  }

  union HexDouble u;
  u.u = (uint64_t) bexp << 52;
  u.u += ((uint64_t) n2<<21) + (((n1 >> 10) + 1) >> 1);
  return u.d;
}

// Convert M_APM number to C double
//
double m_apm_to_double(M_APM r)
{
  if (r->m_apm_sign == 0) return 0.0;
  if (r->m_apm_exponent > EXP_MAX) return r->m_apm_sign * HUGE_VAL;
  if (r->m_apm_exponent < EXP_MIN) return r->m_apm_sign * 0.0;

  UCHAR *data = r->m_apm_data;
  uint64_t bot=0, top = *data++;

  int nbytes = (1 + r->m_apm_datalength) >> 1;
  int nexp   = r->m_apm_exponent;
  int i, len = (nbytes < 9) ? nbytes : 9;

  while (--len)               // build to 18 digits
    top = 100 * top + *data++;

  if (nbytes > 9) {           // build to 30 digits
    if (nbytes > 15) nbytes = 15;
    len = nbytes - 9;
    uint64_t mid = (top >> 20) & 0xfffff;
    bot = top & 0xfffff;
    top >>= 40;
    do {
      bot = 100 * bot + *data++;
      mid *= 100;
      top *= 100;
    } while (--len);
    mid += ((top & 0xffffff) << 20) + (bot >> 20);
    top = (top>>24) + (mid>>44);
    bot = (bot & 0xfffff) | (mid << 20);
    top <<= i = clzll(top);
    top |= bot >> (64-i);
    bot = bot << i >> 32;
    i -= 64;
  } else
    top <<= (i = clzll(top));

  nexp -= 2 * nbytes;
  return r->m_apm_sign * M_to_double(r, top, bot, 64+BIAS-i, nexp);
}

// Convert a double into M_APM, rounded to places
// For exact conversion, set places = -1

void M_set_double(M_APM r, double d, int places)
{
  union HexDouble hd = {fabs(d)};
  int bexp = hd.u >> 52;
  hd.u &= ~0ULL>>12;
  if (bexp == 0x7ff) {    // nan or +/- inf
    M_apm_error(M_APM_RETURN,
      "M_set_double, Invalid input (likely a NAN or INF)");
    M_set_to_zero(r);
    return;
  }
  if (bexp) {             // normal number
    hd.u |= 1ULL<<52;     // add implied bits
    bexp -= BIAS + 54;
  } else {                // zero or subnormals
    if (hd.u == 0) {M_set_to_zero(r); return;}
    bexp -= BIAS + 53;
  }

  m_apm_set_uint64_t(r, hd.u);
  m_apm_ishift(r, bexp);
  if (d < 0) r->m_apm_sign = -1;
  m_apm_iround(r, places);
}
