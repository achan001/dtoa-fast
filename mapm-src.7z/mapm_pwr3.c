#include "m_apm.h"
// z = x ^ n % m
// Assumed x, n, m all integers, n >= 0

void m_apm_powmod(M_APM z, M_APM x, M_APM n, M_APM m)
{
  m_apm_copy(z, MM_One);
  if (n->m_apm_exponent <= 0) return;
  
  M_APM bits = M_get_stack_var();  
  bits->m_apm_datalength = 0;   // all bits to 0
  M_apm_pad(bits, 0, 7 * n->m_apm_exponent);
  UCHAR *bit = bits->m_apm_data;
  
  M_APM q = M_get_stack_var();
  m_apm_copy(q, n);  
  for(;; bit++) {
    M_mul_digit(q, q, 50);      // decompose n to bits
    if (q->m_apm_datalength <= (q->m_apm_exponent -= 2)) continue;
    if(*bit = 1, --q->m_apm_datalength == 0) break;
    M_apm_normalize(q);         // remove 0.5
  }
  M_APM r = M_get_stack_var();  
  do {
    m_apm_square(r, z);         // build x ^ bits_of_n % m
    if (*bit) {SWAP(M_APM, q, r); m_apm_multiply(r, x, q);}
    m_apm_integer_div_rem(q, z, r, m);
  } while (bit-- > bits->m_apm_data);
  M_restore_stack(3);
}
