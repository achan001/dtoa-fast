#ifndef _DTOAFAST_H_
#define _DTOAFAST_H_

#include <math.h>
#include <fenv.h>
#include <errno.h>
#include <float.h>
#include <string.h>
#include "common.h"

#ifdef __cplusplus
extern "C" {
#endif
double strtod_fast(const char *s, char **e);
char* dtoa_fast(double x, int digits, int *sgn, int *len, int *dec);
char* dtoa_ifmt(char *s, int sgn, int len, int dec, char mode);
#ifdef __cplusplus
}
#endif

#ifndef DEBUG
#define DEBUG     0
#endif
#define EPRINT(...)     if (DEBUG) fprintf(stderr, __VA_ARGS__)
#define E_FMT           "0x0.%08x,%08x,%08xp%+-5d\t%s\n"
#define BIT96(s)        EPRINT(E_FMT, n2,n1,n0,bexp-BIAS,s)
#define KEEP30(m,s)     (s = m>>30, m &= (1<<30)-1)

#define HOLE      ~25U          // accuracy of 96-bits
#define ERR       0x1p-35       // frac 35+ bits accurate
#define BIAS      1021          // x = 0x.ddddd ... p(bexp-BIAS)
#define LAST      20            // last digit index
#define EXP_MIN   -323          // below 0.1e-323 -> zero
#define EXP_MAX   +309          // above 0.9e+309 -> inf

#define DIV_1E73(n2,n1,n0,bexp) \
  MUL96(n2,n1,n0,bexp,0xb4ecd5f0ULL,0x1a4aa828ULL,0x1e38aeb6ULL,-242)
#define MUL_1E60(n2,n1,n0,bexp) \
  MUL96(n2,n1,n0,bexp,0x9f4f2726ULL,0x179a2245ULL,0x01d76242ULL,200)
#define MUL_1E25(n2,n1,n0,bexp) \
  MUL64(n2,n1,n0,bexp,0x84595161ULL,0x401484A0ULL,84)
#define MUL_1E12(n2,n1,n0,bexp) \
  MUL32(n2,n1,n0,bexp,0xe8d4a510ULL,40)

#define MUL96(n2,n1,n0,bexp, t2,t1,t0,t_bexp) do {\
  uint64_t x0 = t2 * n0  + t1 * n1 + t0 * n2;\
  uint64_t x1 = (x0>>32) + t2 * n1 + t1 * n2;\
  uint64_t x2 = (x1>>32) + t2 * n2;\
  NORMALIZE(n2,n1,n0,bexp, x2,x1,x0,t_bexp);\
} while(0)

#define MUL64(n2,n1,n0,bexp, t1,t0,t_bexp) do {\
  uint64_t x0 = t1 * n0  + t0 * n1;\
  uint64_t x1 = (x0>>32) + t1 * n1 + t0 * n2;\
  uint64_t x2 = (x1>>32) + t1 * n2;\
  NORMALIZE(n2,n1,n0,bexp, x2,x1,x0,t_bexp);\
} while(0)

#define MUL32(n2,n1,n0,bexp, k,k_bexp) do {\
  uint64_t x0 = (uint64_t) k * n0;\
  uint64_t x1 = (x0>>32) + (uint64_t) k * n1;\
  uint64_t x2 = (x1>>32) + (uint64_t) k * n2;\
  NORMALIZE(n2,n1,n0,bexp, x2,x1,x0,k_bexp);\
} while(0)

#define NORMALIZE(n2,n1,n0,bexp, x2,x1,x0,size)\
if (x2 & (1ULL<<63)) {\
  n2 = (x2 >> 32); n1 = x2; n0 = x1;\
  bexp += (size);\
} else {\
  n2 = x2 >> 31;\
  n1 = ((unsigned) x1 >> 31) | ((unsigned) x2 << 1);\
  n0 = ((unsigned) x0 >> 31) | ((unsigned) x1 << 1);\
  bexp += (size) - 1;\
}
#endif
