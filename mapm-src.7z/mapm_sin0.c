#include "m_apm.h"

/*
                      x^3     x^5     x^7     x^9
     sin(x)  =  x  -  ---  +  ---  -  ---  +  ---  ...
                       3!      5!      7!      9!
*/

void M_raw_sin(M_APM rr, int places, M_APM xx)
{
  int tolerance, dplaces, local_precision, m1;

  M_APM sum  = M_get_stack_var();
  M_APM term = M_get_stack_var();
  M_APM tmp7 = M_get_stack_var();
  M_APM tmp8 = M_get_stack_var();

  m_apm_square(rr, xx);
  rr->m_apm_sign *= -1;

  m_apm_copy(sum, xx);
  m_apm_copy(term, xx);

  dplaces   = (places + 8) - xx->m_apm_exponent;
  tolerance = 4 - dplaces - rr->m_apm_exponent;

  for(m1=2; term->m_apm_exponent >= tolerance; m1 += 2)
  {
    local_precision = dplaces + term->m_apm_exponent;
    m_apm_iround(rr, local_precision);
    m_apm_iround(term, local_precision);
    m_apm_multiply(tmp8, term, rr);
    m_apm_iround(tmp8, local_precision);

    m_apm_set_unsigned(tmp7, m1 * (m1 + 1));
    m_apm_divide(term, local_precision, tmp8, tmp7);
    m_apm_add(tmp7, sum, term);
    SWAP(M_APM, sum, tmp7);
  }
  m_apm_round(rr, places + 6, sum);
  M_restore_stack(4);
}

/****************************************************************************/
/*
                 x^2     x^4     x^6     x^8
cos(x)  =  1  -  ---  +  ---  -  ---  +  ---  ...
                  2!      4!      6!      8!
*/

void M_raw_cos(M_APM rr, int places, M_APM xx)
{
  int tolerance, dplaces, local_precision, m1;

  M_APM sum  = M_get_stack_var();
  M_APM term = M_get_stack_var();
  M_APM tmp7 = M_get_stack_var();
  M_APM tmp8 = M_get_stack_var();

  m_apm_square(rr, xx);
  m_apm_iround(rr, dplaces = places + 8);
  rr->m_apm_sign *= -1;

  M_mul_digit_exp(term, rr, 50, -2);
  m_apm_add(sum, MM_One, term);

  tolerance = 4 - dplaces - term->m_apm_exponent;

  for(m1=3; term->m_apm_exponent >= tolerance; m1 += 2)
  {
    local_precision = dplaces + term->m_apm_exponent;
    m_apm_iround(rr, local_precision);
    m_apm_iround(term, local_precision);
    m_apm_multiply(tmp8, term, rr);
    m_apm_iround(tmp8, local_precision);

    m_apm_set_unsigned(tmp7, m1 * (m1 + 1));
    m_apm_divide(term, local_precision, tmp8, tmp7);
    m_apm_add(tmp7, sum, term);
    SWAP(M_APM, sum, tmp7);
  }
  m_apm_round(rr, places + 6, sum);
  M_restore_stack(4);
}
