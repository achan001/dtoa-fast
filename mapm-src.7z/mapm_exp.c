#include "m_apm.h"

void M_raw_exp(M_APM r, int places, M_APM x)
{
  M_APM M1    = M_get_stack_var();
  M_APM tmp   = M_get_stack_var();
  M_APM sum   = M_get_stack_var();
  M_APM term  = M_get_stack_var();

  int prev_exp  = x->m_apm_exponent;
  int tolerance = -(places + 5);
  int dplaces   = places + 8 + prev_exp;

  m_apm_round(r, dplaces, x);
  m_apm_add(sum, MM_One, r);
  m_apm_copy(term, r);

  // exp(x) = 1 + x + x^2/2! + x^3/3! + ...
  // |e| < 1E-4 (from M_apm_exp) -> accuracy = places + 8

  for (int m1=2 ;; m1++)
  {
    m_apm_set_unsigned(M1, m1);
    m_apm_multiply(tmp, term, r);
    m_apm_iround(tmp, dplaces);
    m_apm_divide(term, dplaces, tmp, M1);
    m_apm_add(tmp, sum, term);

    int term_exp = term->m_apm_exponent;
    if (term_exp <= tolerance) break;
    dplaces -= prev_exp - term_exp;
    prev_exp = term_exp;
    m_apm_iround(term, dplaces);
    m_apm_iround(r, dplaces);
    SWAP(M_APM, tmp, sum);
  }
  m_apm_copy(r, tmp);
  M_restore_stack(4);
}

void M_apm_exp(M_APM r, int places, M_APM x)
{
  if (x->m_apm_exponent < -3) {M_raw_exp(r, places, x); return;}

  int n = 0;
  int dplaces = places + 14;
  M_APM y = M_get_stack_var();

  if (x->m_apm_exponent > 2)      // |x| >= 100 -> x = y + n log10
  {
    if (x->m_apm_exponent > 9)
    {
      M_apm_error(M_APM_RETURN, "M_apm_exp, Input too big");
      M_set_to_zero(r);
      return;
    }
    n = lrint(m_apm_to_double(x) * M_LOG10E);
    m_apm_set_long(y, n);
    M_check_log_places(dplaces);
    m_apm_multiply(r, y, MM_lc_LOG_10);
    m_apm_subtract(y, x, r);      // |y| <= 0.5 log10 < 1.1513
    x = y;
  }

  m_apm_multiply(r, x, MM_1024R); // max(|x|) = 100
  m_apm_multiply(y, r, MM_1024R); // max(|y|) = 100/2^20 < 1E-4
  M_raw_exp(r, places + 4, y);    // exp(y/2^20)

  for(int i=10 ; i--;)            // exp(y) = exp(y/2^20) ^ (2^20)
  {
    m_apm_iround(r, dplaces);
    m_apm_square(y, r);
    m_apm_iround(y, dplaces);
    m_apm_square(r, y);
  }
  r->m_apm_exponent += n;         // exp(x) = exp(y) * 10 ^ n
  M_restore_stack(1);
}

void m_apm_exp(M_APM r, int places, M_APM x)
{
  M_apm_exp(r, places, x);
  m_apm_iround(r, places);
}
